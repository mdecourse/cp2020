i = 4

print(i)