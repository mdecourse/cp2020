#define MAXLINES 1000
#define MAXLEN 1000

void print_array(char s[]);
void print_sparse_array(char s[][MAXLEN]);
int itob(int n, char s[], int b);

