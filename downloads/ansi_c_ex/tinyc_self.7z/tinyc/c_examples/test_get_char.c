#include <stdio.h>

main()
{
	int test;
	int c;

	test = getchar() != EOF;

	printf("%d\n", test);
}
