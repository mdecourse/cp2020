/* Hello World program */

#include<stdio.h>

main()
{
    int i;
    
    for (i=0; i<10; i++){
        printf("Hello World\n");
    }

}
