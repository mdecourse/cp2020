 #define TCC_VERSION "0.9.27"
