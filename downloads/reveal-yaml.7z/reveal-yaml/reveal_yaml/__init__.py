# -*- coding: utf-8 -*-

__version__ = '2.3.0'
__author__ = "Yuan Chang"
__copyright__ = "Copyright (C) 2019-2020"
__license__ = "MIT"
__email__ = "pyslvs@gmail.com"
